#ifndef PESSOA_JURIDICA_H
#define PESSOA_JURIDICA_H

#include "pessoa.h"
#include <string>
using namespace std;

class PessoaJuridica : public Pessoa
{
    public:
        PessoaJuridica(string nome, string cnpj = 0) : Pessoa(nome), cnpj(cnpj){}
        ~PessoaJuridica(){}

        PessoaJuridica &setCNPJ(string const &CNPJ) {cnpj = CNPJ;return *this;}
        string getCNPJ() const {return cnpj;}
        string getTipo(){return "Jurídica";}

    private:
        string nome;
        string cnpj;
        
};
#endif
