#include "contapoup.h"
#include <string>
#include <iostream>
#include <vector>
using namespace std;

//DEPOSITO
bool ContaPoupanca::operator << (double &valor)
{
    int opcao;
    cout<<"Digite 1 para CONFIRMAR o depósito ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if (opcao)
    {
        saldo += valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Deposito");
        return true;
    }
    return false;
}

//SAQUE
bool ContaPoupanca::operator >>(double &valor)
{
    if (valor > saldo)
        return false;

    int opcao;
    cout<<"Digite 1 para CONFIRMAR o saque ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if (opcao)
    {
        saldo -= valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Saque");
        return true;
    }
    return false;
}

//IMPRESSÃO DO EXTRATO
void ContaPoupanca::extrato()
{   
    cout << "CONTA: " << conta << endl;
    //cout << "CLIENTE: " << nome << endl;
    cout << "ANIVERSARIO: "<< aniversario <<endl;
    cout << "Transações: " << endl;

    if(data.size() >= 30)
    {
        for (int i = (data.size() - 30) ; i < data.size() ; i++)
        cout << data[i] << " " << valores[i] << " " << descricao[i] << endl;
        cout << "------------------------------" << endl;
        cout << "Saldo: R$ " << saldo << endl;
    }
    else
    {
        for (int i = 0 ; i <= data.size() ; i++)
        cout << data[i] << " " << valores[i] << " " << descricao[i] << endl;
        cout << "------------------------------" << endl;
        cout << "Saldo: R$ " << saldo << endl;
    }

}

//TRANFERENCIA
bool ContaPoupanca::transferencia(double valor, Conta &aux)
{
    if (valor > saldo)
        return false;

    int opcao;
    cout<<"Digite 1 para CONFIRMAR a tranferencia ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if(opcao)
    {
        //somando na outra conta
        double x = aux.getSaldo();
        x+= valor;
        aux.setSaldo(x);
        //subtraindo na conta atual
        saldo-=valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Transferencia");
        return true;
    }
    return false;
}