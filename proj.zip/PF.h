#ifndef PESSOA_FISICA_H
#define PESSOA_FISICA_H

#include "pessoa.h"
#include <string>
#include <iostream>
using namespace std;

class PessoaFisica : public Pessoa
{
    public:
        PessoaFisica(string nome, string cpf) : Pessoa(nome), cpf(cpf){}
        ~PessoaFisica(){}

        PessoaFisica &setCPF(string const &CPF) {cpf = CPF;return *this;}
        string getCPF() const {return cpf;}
        string getTipo(){return "Física";}

    private:
        string nome;
        string cpf;
};
#endif