#ifndef CONTA_COMUM_H
#define CONTA_COMUM_H

#include "conta.h"
#include <string>
#include <vector>
using namespace std;

class ContaComum : public Conta
{
    public:
        ContaComum(int conta,Pessoa *tit , double saldo = 0.0) : Conta(conta,tit, saldo) {}
        
        virtual ~ContaComum(){}

        //DEPOSITO
        bool operator <<(double &valor);

        //SAQUE
        bool operator >>(double &valor);

        //IMPRESSÃO DO EXTRATO
        void extrato();

        //TRANFERENCIA
        bool transferencia(double valor, Conta &);
    private:
        vector <string> data;
        vector <string> descricao;
        vector <string> valores;
};

#endif