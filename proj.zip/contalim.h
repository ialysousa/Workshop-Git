#ifndef CONTA_LIMITE_H
#define CONTA_LIMITE_H

#include "conta.h"
#include <vector>
#include <iostream>
using namespace std;

class ContaLimite : public Conta
{
    public:
        ContaLimite(int conta,Pessoa *tit, double limite = 200.0, double saldo = 0.0) : Conta(conta,tit, saldo),limite(limite) {}
        
        virtual ~ContaLimite(){}

        //DEPOSITO
        bool operator << (double &valor);

        //SAQUE
        bool operator >>(double &valor);

        //IMPRESSÃO DO EXTRATO
        void extrato();

        //TRANFERENCIA
        bool transferencia(double valor, Conta &);

    private:
        double limite;
        vector <string> data;
        vector <string> descricao;
        vector <string> valores;
};

#endif