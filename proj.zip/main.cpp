#include <iostream>
using std::cout, std::endl;

#include "PF.h"
#include "PJ.h"
#include "banco.h"
#include "contacom.h"
#include "contalim.h"
#include "contapoup.h"

void Gerente(Banco &b);

int main() {
  Banco b();
  	
  
 

 
  return 0;
}



