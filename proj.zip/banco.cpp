#include "banco.h"
#include <string>
#include <iostream>
using std::cout, std:: cin, std::endl;

bool Banco::CadastroCorrentista()
{
    int op;
    cout<<"Bem-vindo!"<<endl<<"Para cadastro de Pessoa Física, digite > 1 <;"<<endl<<"Para cadastro de Pessoa Jurídica, digite > 2 <"<<endl;
    cin>>op;

    string nome_aux;
    cout<<"Insira o seu nome completo:"<<endl;
    getline(cin, nome_aux);
    if (EncontraCorrentista(nome_aux) != 0)
        cout<<"Você já possui um cadastro!"<<endl;
    else
    {
        if(op == 1)
        {
            string cpf_aux;
            cout<<"Insira o seu CPF (apenas números):"<<endl;
            getline(cin, cpf_aux);

            pessoas[num_pessoas] = new PessoaFisica(nome_aux,cpf_aux);
            cout<<"Querido(a) "<<nome_aux<<", seu cadastro foi feito com sucesso!"<<endl;
            num_pessoas++;
            return true;
        }
        else if(op == 2)
        {
            string cnpj_aux;
            cout<<"Insira o seu CNPJ (apenas números):"<<endl;
            getline(cin, cnpj_aux);

            pessoas[num_pessoas] = new PessoaJuridica(nome_aux,cnpj_aux);
            cout<<"Querido(a) "<<nome_aux<<", seu cadastro foi feito com sucesso!"<<endl;
            num_pessoas++;
            return true;
        }
    }
    return false;
}

int Banco::EncontraCorrentista(string nome)
{
    for (int a = 0; a <= num_pessoas; a++)
    {
        if (pessoas[num_pessoas]->getNome() == nome)
            return a;
    }
    return 0;
}

bool Banco::CadastroConta()
{
    cout << "Cadastrar uma nova Conta." << endl;
    cout<<"O titular já está cadastrado no sistema? "<<endl;
    cout<<"Digite 1 para SIM ou 2 para NÃO."<<endl;
    int opp;
    cin>>opp;

    if (opp == 2) CadastroCorrentista();
    else if( opp == 1)
    {
        int op1;
        cout<<"Qual o tipo de conta que você deseja abrir?:"<<endl;
        cout<<"1-> Conta Comum;"<<endl<<"2-> Conta Limite;"<<endl<<"3-> Conta Poupança;"<<endl;
        cin>>op1;

        string nomeaux,niver;
        cout<<"Insira o seu nome completo:"<<endl;
        getline(cin, nomeaux);

        switch (op1)
        {
        case 1:
            ContaComum(num_contas*100, pessoas[EncontraCorrentista(nomeaux)]);
            num_contas++;
            return true;
        case 2:
            int limite; 
            cout<<"Qual o limite da sua conta?"<<endl;
            ContaLimite(num_contas*100, pessoas[EncontraCorrentista(nomeaux)],limite);
            num_contas++;
            return true;
        case 3:
            cout<<"Insira a data da criação da contano formato DD/MM/AAAA:"<<endl;
            cin>>niver;
            ContaPoupanca(num_contas*100,pessoas[EncontraCorrentista(nomeaux)],niver);
            num_contas++;
            return true;
        default:
            return false;
        }
    }
    return false;
}

bool Banco::ConsultaConta(int conta) const
{
    for (int i = 0; i < num_contas; i++){
        if (conta == ListaContas[i]->getConta()){
        
        cout << "=========Dados sobre a conta: =========" << endl;
        cout << "Numero da conta: " << ListaContas[i]->getConta() << endl;
        cout << "Nome do correntista: " << ListaContas[i]->getNome() << endl;
        cout << "Saldo: " << ListaContas[i]->getSaldo() << endl;
        cout << endl;
        return true;
        }
    }
    cout << "Não encontrado!" << endl;
    return false;
}
