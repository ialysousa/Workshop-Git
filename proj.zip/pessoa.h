#ifndef PESSOA_H
#define PESSOA_H
#include <iostream>
#include <string>
using namespace std;

class Pessoa
{
    public:
        Pessoa(string nome) : nome(nome) {}
        Pessoa(){}
        virtual ~Pessoa() {}
        
        Pessoa &setNome(string const &NOME) {nome = NOME;return *this;}
        string getNome() const {return nome;}
        virtual string getTipo() = 0;

    protected:
        string nome;
};

#endif