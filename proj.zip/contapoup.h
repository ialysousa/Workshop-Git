#ifndef CONTA_POUPANCA_H
#define CONTA_POUPANCA_H

#include "conta.h"
#include <vector>
#include <string>
using namespace std;

class ContaPoupanca : public Conta
{
    public:
        ContaPoupanca(int conta, Pessoa *tit, string aniversaio, double saldo = 0.0) : Conta(conta,tit, saldo),aniversario(aniversaio) {}
        
        virtual ~ContaPoupanca(){}

        //DEPOSITO
        bool operator << (double &valor);

        //SAQUE
        bool operator >>(double &valor);

        //IMPRESSÃO DO EXTRATO
        void extrato();

        //TRANFERENCIA
        bool transferencia(double valor, Conta &);

    private:
        string aniversario;
        vector <string> data;
        vector <string> descricao;
        vector <string> valores;
};

#endif