#ifndef CONTA_H
#define CONTA_H
#include <time.h>
#include <string>
#include "pessoa.h"
using namespace std;

class Conta 
{
    public:
        Conta(int conta,Pessoa *tit, double saldo = 0.0): conta(conta),saldo(saldo), titular(tit) {}
  
        virtual ~Conta(){}

        //DEPOSITO
        virtual bool operator << (double &valor) = 0;

        //SAQUE
        virtual bool operator >>(double &valor) = 0;

        //IMPRESSÃO DO EXTRATO
        virtual void extrato() = 0;

        //TRANFERENCIA
        virtual bool transferencia(double valor, Conta &) = 0;

        //Pegar a data do sistema no dia da transação
        string Data()
        {
            string data;
            time_t mytime;

            mytime = time(NULL);
            struct tm tm = *localtime(&mytime);

            data += to_string(tm.tm_mday) +"/"+ "0" + to_string(tm.tm_mon+1) +"/"+ to_string(tm.tm_year + 1900);
            return data;
        }

        void setSaldo (double &SALDO) {saldo = SALDO;}
        double getSaldo() const {return saldo;}

        int getConta() const {return conta;}
        string getNome(){return titular->getNome();}
        
    protected:
        int conta;
        double saldo;
        Pessoa *titular;
};

#endif