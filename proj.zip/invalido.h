#ifndef VALOR_INVALIDO_H
#define VALOR_INVALIDO_H

#include <stdexcept>

class ValorInvalido : public std::out_of_range
{
public:
  ValorInvalido(const char *e="Valor invadido! Tente novamente."): out_of_range(e) {}
};

#endif