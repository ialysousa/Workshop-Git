#include "contalim.h"
#include <string>
#include <iostream>
#include <vector>
using namespace std;

//DEPOSITO
bool ContaLimite::operator << (double &valor)
{
    int opcao;
    cout<<"Digite 1 para CONFIRMAR o depósito ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if (opcao)
    {
        saldo += valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Deposito");
        return true;
    }
    return false;
}

//SAQUE
bool ContaLimite::operator >>(double &valor)
{
    if (valor > saldo + limite)
        return false;

    int opcao;
    cout<<"Digite 1 para CONFIRMAR o saque ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if (opcao)
    {
        saldo -= valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Saque");
        return true;
    }
    return false;
}

//IMPRESSÃO DO EXTRATO
void ContaLimite::extrato()
{   
    cout << "CONTA: " << conta << endl;
    //cout << "CLIENTE: " << nome << endl;
    cout << "LIMITE: "<< limite <<endl;
    cout << "Transações: " << endl;

    if(data.size() >= 30)
    {
        for (int i = (data.size() - 30) ; i < data.size() ; i++)
        cout << data[i] << " " << valores[i] << " " << descricao[i] << endl;
        cout << "------------------------------" << endl;
        cout << "Saldo: R$ " << saldo << endl;
    }
    else
    {
        for (int i = 0 ; i <= data.size() ; i++)
        cout << data[i] << " " << valores[i] << " " << descricao[i] << endl;
        cout << "------------------------------" << endl;
        cout << "Saldo: R$ " << saldo << endl;
    }

}

//TRANFERENCIA
bool ContaLimite::transferencia(double valor, Conta &aux)
{
    if (valor > saldo + limite)
        return false;

    int opcao;
    cout<<"Digite 1 para CONFIRMAR a tranferencia ou 0 para CANCELAR:"<<endl;
    cin>>opcao;

    if(opcao)
    {
        //somando na outra conta
        double x = aux.getSaldo();
        x+= valor;
        aux.setSaldo(x);
        //subtraindo na conta atual
        saldo-=valor;
        data.push_back(Data());
        valores.push_back(to_string(valor));
        descricao.push_back("Transferencia");
        return true;
    }
    return false;
}