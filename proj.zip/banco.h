#ifndef BANCO_H
#define BANCO_H

#include <string>
#include "PJ.h"
#include "PF.h"
#include "conta.h"
#include "contacom.h"
#include "contalim.h"
#include "contapoup.h"
using namespace std;

class Banco : PessoaJuridica
{
    public:
        Banco();
        ~Banco();
        bool CadastroCorrentista();
        bool CadastroConta();
        bool RemoveConta();
        bool ConsultaConta(int conta) const;
        bool AtualizaConta();
        int EncontraCorrentista(string nome);

    protected:
    string nomebanco;
    Pessoa *pessoas[100];
    Conta *ListaContas[100];
    int num_contas = 0, num_pessoas = 0;

};

#endif